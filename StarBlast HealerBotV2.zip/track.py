from os import times
import pydirectinput
import cv2 as cv
import numpy as np
from time import sleep
from windowcapture import WindowCapture
import pydirectinput

pydirectinput.PAUSE = 0.001


class Tracker:
    
    middleHeight = 0
    middleWidth = 0
    x_medium = 0
    y_medium = 0
    color = 0

    def __init__(self, window_offset, window_size):

        # for translating window positions into screen positions, it's easier to just
        # get the offsets and window size from WindowCapture rather than passing in 
        # the whole object
        self.window_offset_x = window_offset[0]
        self.window_offset_y = window_offset[1] 
        self.window_w = window_size[0]
        self.window_h = window_size[1]

    def function(self, putithere):
        
        #Define selfs



        #Find the middle of the screen
        self.middleHeight = int(putithere.shape[0] / 2)
        self.middleWidth = int(putithere.shape[1] / 2)
        
        #All the visual processing
        hsv_frame = cv.cvtColor(putithere, cv.COLOR_BGR2HSV)
        
        low_red  = np.array([20, 100, 100])
        high_red = np.array([30, 170 ,255])
        red_mask = cv.inRange(hsv_frame, low_red, high_red)
        
        contours, _ = cv.findContours(red_mask, cv.RETR_TREE, cv.CHAIN_APPROX_SIMPLE)
        contours = sorted(contours, key=lambda x:cv.contourArea(x), reverse=True)

        #Draw contours
        cv.drawContours(putithere, contours, -1, (255,255,255),4)

        for cnt in contours:
            (x, y, w, h) = cv.boundingRect(cnt)

            #Pinpoint the contours
            self.x_medium = int((x + x + w) / 2)
            self.y_medium = int((y + y + h) / 2) - 20

            #Contour crosshair
            cv.line(putithere, (self.x_medium, 0), (self.x_medium, (1000)), (0, 255, 0), 2)
            cv.line(putithere, (0, self.y_medium), ((1000), self.y_medium), (0, 255, 0), 2)

            #Box target 
            cv.rectangle(putithere, (x, y), (x + w, y + h), (0, 255, 0), 1)

            break

        #Crosshair
        add = 50
        cv.rectangle(putithere, (self.middleWidth - add, self.middleHeight - add), (self.middleWidth + add, self.middleHeight + add), (self.color, 0, 0), 2)
    
        #X
        left = self.middleWidth - add
        right = self.middleWidth + add
        #Y
        top = self.middleHeight - add
        bottom = self.middleHeight + add

        if not contours:
            #Don't do anything and default color/coordinates
            self.color = 0
            pydirectinput.mouseUp()
            pydirectinput.mouseUp(button='right')
            pass
        elif self.x_medium >= left and self.x_medium <= right and self.y_medium >= top and self.y_medium <= bottom:
            #Inside the box
            self.color = 255
            pydirectinput.mouseDown()
            pydirectinput.mouseUp(button='right')
            pydirectinput.moveTo(self.x_medium + self.window_offset_x,self.y_medium + self.window_offset_y)
        else:
            #Outside the box
            self.color = 0
            pydirectinput.mouseUp()
            pydirectinput.mouseDown(button='right')
            pydirectinput.moveTo(self.x_medium + self.window_offset_x,self.y_medium + self.window_offset_y)
            pass

        #print(self.x_medium, self.y_medium)

        cv.imshow("AA", putithere)