import cv2 as cv
import numpy as np
import os
import win32gui
from time import time

from numpy.core.fromnumeric import trace
from windowcapture import WindowCapture
from track import Tracker

# Change the working directory to the folder this script is in.
# Doing this because I'll be putting the files from each video in their 
# own folder on GitHub
os.chdir(os.path.dirname(os.path.abspath(__file__)))

DEBUG = True

windowname = "STARBLAST.IO - K-Meleon"

#Resize the window resolution
hwnd = win32gui.FindWindow(None, windowname)
win32gui.MoveWindow(hwnd, 800, 0, 720, 360, True)
bbox = win32gui.GetWindowRect(hwnd)

#Print the 

# initialize the WindowCapture class
wincap = WindowCapture(windowname)


#Start Window Capture thrread.
wincap.start()
tracker = Tracker((wincap.offset_x, wincap.offset_y), (wincap.w, wincap.h))

while(True):

    # if we don't have a screenshot yet, don't run the code below this point yet
    if wincap.screenshot is None:
        continue


    tracker.function(wincap.screenshot)
    

    # press 'q' with the output window focused to exit.
    # waits 1 ms every loop to process key presses
    key = cv.waitKey(1)
    if key == ord('q'):
        wincap.stop()
        cv.destroyAllWindows()
        break

print('Done.')

